import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styles: []
})
export class AppComponent implements OnInit {
    records = [];
    loading: boolean = true;

    constructor(
        private dataService: DataService,
    ) { }

    ngOnInit() {
        this.GetAllRecords();
    }

    GetAllRecords() {
        this.dataService.GetAlbumsRecord().subscribe(records => {
            this.loading = false;
            this.records = records;
        });
    }
}
