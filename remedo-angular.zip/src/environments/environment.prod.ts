export const environment = {
    production: true,
    APIURL: 'https://jsonplaceholder.typicode.com/'
};
